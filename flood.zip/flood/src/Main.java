import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Random;
import java.util.Stack;

public class Main {

    private static int N = 15;
    private static int M = 15;

    public static void main(String[] args) {

        Color[] colors = new Color[] {
                new Color(17, 61, 147),
                new Color(215, 55, 69),
                new Color(0, 149, 72),
                new Color(139, 71, 175),
                new Color(244, 92, 41),
                new Color(251, 197, 49),
                new Color(5, 161, 162),
                new Color(167, 38, 108),
                new Color(47, 167, 25),
                new Color(231, 112, 0)
        };
        int[][] colorMatrix = generateMatrix(N,M);


        JFrame frame = new JFrame("DFS (Depth-First-Search) Flooder");
        Dimension dimension = new Dimension(35*colorMatrix.length, 35*colorMatrix[0].length);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setResizable(false);

        GridLayout gridLayout = new GridLayout(colorMatrix.length, colorMatrix[0].length);
        JPanel board = new JPanel();
        board.setDoubleBuffered(true);
        board.setLayout(gridLayout);
        board.setSize(dimension);
        board.setPreferredSize(dimension);

        JPanel[][] tiles = new JPanel[colorMatrix.length][colorMatrix[0].length];
        for (int i = 0; i < colorMatrix.length; i++) {
            for (int j = 0; j < colorMatrix[0].length; j++) {
                tiles[i][j] = new JPanel();
                tiles[i][j].setBackground(colors[colorMatrix[i][j]]);
                tiles[i][j].setBorder(new LineBorder(Color.BLACK));
                tiles[i][j].addMouseListener(new MouseAdapter() {
                    @Override
                    public void mouseClicked(MouseEvent e) {
                        JPanel tile = (JPanel) e.getSource();
                        int c = colorIdx(tile.getBackground(), colors);
                        flood(colorMatrix, c);
                        updateBg(colorMatrix, tiles, colors);
                    }
                });
                board.add(tiles[i][j]);
            }
        }


        frame.add(board);
        frame.pack();
        frame.setVisible(true);
    }


    private static int[][] generateMatrix(int rows, int columns) {
        Random random = new Random();
        int[][] mtx = new int[rows][columns];
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                mtx[i][j] = random.nextInt(10);
            }
        }
        return mtx;
    }

    private static void flood(int[][] colorMatrix, int color) {
        boolean visited[][] = new boolean[colorMatrix.length][colorMatrix[0].length];
        Stack<int[]> stack = new Stack<>();

        int initialColor = colorMatrix[0][0];
        int[] initialPosition = new int[] {0, 0};
        stack.push(initialPosition);

        while (!stack.isEmpty()) {
            int[] current = stack.pop();
            int i = current[0];
            int j = current[1];
            if (!visited[i][j]) {
                visited[i][j] = true;
                if (i > 0) { if (isValid(i-1, j, visited, colorMatrix, initialColor)) stack.push(new int[] {i-1, j}); }
                if (i < colorMatrix.length-1) { if (isValid(i+1, j, visited, colorMatrix, initialColor)) stack.push(new int[] {i+1, j}); }
                if (j > 0) { if (isValid(i, j-1, visited, colorMatrix, initialColor)) stack.push(new int[] {i, j-1}); }
                if (j < colorMatrix[0].length-1) { if (isValid(i, j+1, visited, colorMatrix, initialColor)) stack.push(new int[] {i, j+1}); }
            }
        }
        for (int i = 0; i < colorMatrix.length; i++) {
            for (int j = 0; j < colorMatrix[0].length; j++) {
                if (visited[i][j]) colorMatrix[i][j] = color;
            }
        }
    }

    private static boolean isValid(int i, int j, boolean[][] visited, int[][] colorMatrix, int initColor) {
        return (colorMatrix[i][j] == initColor) && !visited[i][j];
    }


    private static int colorIdx(Color color, Color[] colors) {
        for (int i = 0; i < colors.length; i++) {
            if (color == colors[i]) return i;
        }
        return 0;
    }


    private static void updateBg(int[][] colorMatrix, JPanel[][] tiles, Color[] colors) {
        for (int i = 0; i < colorMatrix.length; i++) {
            for (int j = 0; j < colorMatrix[0].length; j++) {
                tiles[i][j].setBackground(colors[colorMatrix[i][j]]);
            }
        }
    }
}
